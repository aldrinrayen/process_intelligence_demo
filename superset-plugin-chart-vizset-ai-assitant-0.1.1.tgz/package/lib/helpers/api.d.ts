import { ChatAI, UserMetaData } from "../types";
export declare const getCharts: (dashboardId: number) => Promise<any>;
export declare const getUserMetaData: (baseURl: string, data: UserMetaData) => Promise<any>;
export declare const createUserMetaData: (baseURl: string, data: UserMetaData) => Promise<any>;
export declare const getChatGroups: (baseURl: string, id: number) => Promise<any>;
export declare const getChatHistory: (baseURl: string, id: number, group_id: number) => Promise<any>;
export declare const askAiAssistant: (baseURl: string, data: ChatAI) => Promise<any>;
export declare const getChartsData: (charts: any[], dashboardId: number) => Promise<{
    success: boolean;
    charts: {
        [key: string]: {
            data: any;
            query: any;
            success: boolean;
            error?: string | undefined;
        };
    };
    totalCharts: number;
    successfulCharts: number;
    failedCharts: number;
    error?: undefined;
} | {
    success: boolean;
    charts: {};
    totalCharts: number;
    successfulCharts: number;
    failedCharts: number;
    error: string;
}>;
export declare const deleteChatGroup: (baseURl: string, id: number) => Promise<any>;
export declare const getDashboardChartsMetadata: (dashboardId: number) => Promise<{
    [chart_id: string]: string;
}>;
export declare const getDataFromExplore: (chartId: number) => Promise<any>;
export declare const GetChartDataWithOutQuery: (chartId: number) => Promise<any>;
//# sourceMappingURL=api.d.ts.map