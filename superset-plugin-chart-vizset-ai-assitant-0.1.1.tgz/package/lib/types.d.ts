/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
import { TimeseriesDataRecord } from '@superset-ui/core';
export declare type UserMetaData = {
    superset_instance: string;
    user_name: string;
    dashboard: number;
    ai_chart_id: number;
};
export declare type ChatAI = {
    question: string;
    user_meta_id: number;
    chat_group_id: number;
    llm_model: string;
    llm_api_key: string;
    charts: {
        [key: string]: {
            data: any;
            query: any;
        };
    };
};
export declare type SupersetPluginChartVizsetAiAssitantProps = {
    data: TimeseriesDataRecord[];
    assistantName: string;
    backendUrl: string;
    themeColor: string;
    gradientColor: string;
    aiProvider: string;
    aiApiKey: string;
    username: string;
    isExpired: boolean;
    metaData: {
        dashboardId: number;
        chartId: number;
    };
    defaultModalSize: string;
};
//# sourceMappingURL=types.d.ts.map