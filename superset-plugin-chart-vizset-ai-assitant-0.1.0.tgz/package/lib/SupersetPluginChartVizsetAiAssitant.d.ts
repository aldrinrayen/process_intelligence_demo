/// <reference types="react" />
import { SupersetPluginChartVizsetAiAssitantProps } from './types';
/**
 * ******************* WHAT YOU CAN BUILD HERE *******************
 *  In essence, a chart is given a few key ingredients to work with:
 *  * Data: provided via `props.data`
 *  * A DOM element
 *  * FormData (your controls!) provided as props by transformProps.ts
 */
export default function SupersetPluginChartVizsetAiAssitant(props: SupersetPluginChartVizsetAiAssitantProps): JSX.Element;
//# sourceMappingURL=SupersetPluginChartVizsetAiAssitant.d.ts.map