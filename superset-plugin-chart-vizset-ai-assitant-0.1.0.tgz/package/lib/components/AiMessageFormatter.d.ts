/// <reference types="react" />
export default function AiMessageFormatter({ text }: {
    text: string;
}): JSX.Element;
//# sourceMappingURL=AiMessageFormatter.d.ts.map