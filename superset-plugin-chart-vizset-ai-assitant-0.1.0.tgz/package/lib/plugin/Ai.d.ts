import React from 'react';
interface FloatingMessageButtonProps {
    assistantName: string;
    backendUrl: string;
    themeColor: string;
    gradientColor: string;
    aiProvider: string;
    aiApiKey: string;
    username: string;
    metaData: {
        dashboardId: number;
        chartId: number;
    };
    defaultModalSize: string;
}
export declare const FloatingMessageButton: React.FC<FloatingMessageButtonProps>;
export {};
//# sourceMappingURL=Ai.d.ts.map