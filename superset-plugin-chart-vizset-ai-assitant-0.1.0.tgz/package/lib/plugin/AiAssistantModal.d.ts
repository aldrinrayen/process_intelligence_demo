import React from 'react';
interface AiAssistantModalProps {
    isOpen: boolean;
    onClose: () => void;
    isExpanded: boolean;
    onToggleExpand: () => void;
    themeColor: string;
    assistantName: string;
    aiProvider: string;
    aiApiKey: string;
    chatGroups: {
        id: number;
        group_name: string;
        updated_at: Date;
        created_at: Date;
        last_message_at: Date;
    }[];
    refreshchatGroups: () => void;
    metaData: {
        dashboardId: number;
        chartId: number;
        backendUrl: string;
        user_meta_id: number;
        charts: any[];
    };
    requestedSliceContext?: {
        sliceId: number;
        sliceName: string;
    };
    defaultModalSize: string;
}
export declare const AiAssistantModal: React.FC<AiAssistantModalProps>;
export {};
//# sourceMappingURL=AiAssistantModal.d.ts.map